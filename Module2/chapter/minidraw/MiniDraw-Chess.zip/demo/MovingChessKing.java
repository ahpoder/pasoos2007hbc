import minidraw.standard.*;
import minidraw.framework.*;

import java.awt.*;
import javax.swing.*;

/** Show chess kings and allow them to move.
 * A demonstration of a "minimal" MiniDraw application.
 * 
 * @author Henrik B�rbak Christensen (c) 2006
 */
public class MovingChessKing {
  
  public static void main(String[] args) {
    DrawingEditor editor = 
      new MiniDrawApplication( "Move kings using the mouse",
                               new ChessFactory() );
    editor.open();
    
    Figure wking = new ImageFigure( "wking", new Point(162, 322));
    Figure bking = new ImageFigure( "bking", new Point(162, 42));

    editor.setTool( new SelectionTool(editor) );

    editor.drawing().add(wking);
    editor.drawing().add(bking);
  }
}

class ChessFactory implements Factory {

  public DrawingView createDrawingView( DrawingEditor editor ) {
    ImageManager im = ImageManager.getSingleton();
    DrawingView view = 
      new StdViewWithBackground(editor, im.getImage("chessboard"));
    return view;
  }

  public Drawing createDrawing( DrawingEditor editor ) {
    return new StandardDrawing();
  }

  public JTextField createStatusField( DrawingEditor editor ) {
    return null;
  }
}
