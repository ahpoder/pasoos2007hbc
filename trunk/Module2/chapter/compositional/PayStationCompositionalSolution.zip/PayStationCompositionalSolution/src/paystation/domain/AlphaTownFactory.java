package paystation.domain;

/** Factory for Alphatown.

    author: (c) Henrik B�rbak Christensen 2006
*/

public class AlphaTownFactory implements PayStationFactory {
  public Receipt createReceipt( int parkingTime ) { 
    return new ReceiptImpl(parkingTime); 
  }
  public RateStrategy createRateStrategy( WeekdayDeterminationStrategy wds ) { 
    return new LinearRateStrategy(); 
  }
  public WeekdayDeterminationStrategy createWeekdayDeterminationStrategy() {
    return new RealWeekdayDeterminationStrategy();
  }
  public DisplayStrategy createDisplayStrategy() {
    return new TimeDisplayStrategy();
  }
}

