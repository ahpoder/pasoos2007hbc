package paystation.domain;

/** Factory for Betatown.

    author: (c) Henrik B�rbak Christensen 2006
*/

public class BetaTownFactory implements PayStationFactory {
  public Receipt createReceipt( int parkingTime ) { 
    return new BarCodeReceipt(parkingTime); 
  }
  public RateStrategy createRateStrategy( WeekdayDeterminationStrategy wds ) { 
    return new ProgressiveRateStrategy(); 
  }
  public WeekdayDeterminationStrategy createWeekdayDeterminationStrategy() {
    return new RealWeekdayDeterminationStrategy();
  }
  public DisplayStrategy createDisplayStrategy() {
    return new ValueDisplayStrategy();
  }
}

