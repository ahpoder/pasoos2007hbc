package paystation.domain;

import java.util.*;

/** A composite rate calculation strategy that
    uses two rate strategies, one for weekdays and
    another for weekends.

    author: (c) Henrik B�rbak Christensen 2006
*/

public class CompositeRateStrategy implements RateStrategy {
  RateStrategy weekendStrategy, weekdayStrategy;
  WeekdayDeterminationStrategy dayDeterminationStrategy;

  public CompositeRateStrategy( RateStrategy weekdayStrategy,
                                RateStrategy weekendStrategy,
                                WeekdayDeterminationStrategy 
                                dayDeterminationStrategy ) {
    this.weekdayStrategy = weekdayStrategy;
    this.weekendStrategy = weekendStrategy;
    this.dayDeterminationStrategy = dayDeterminationStrategy;
  }
  public int calculateTime( int amount ) {
    int time;
    if ( dayDeterminationStrategy.isWeekend() ) {
      time = weekendStrategy.calculateTime( amount );
    } else {
      time = weekdayStrategy.calculateTime( amount );
    }
    return time;
  }
}
