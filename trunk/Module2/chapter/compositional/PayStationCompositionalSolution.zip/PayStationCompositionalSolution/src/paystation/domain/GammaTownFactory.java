package paystation.domain;

/** Factory for Gammatown.

    author: (c) Henrik B�rbak Christensen 2006
*/

public class GammaTownFactory implements PayStationFactory {

  public Receipt createReceipt( int parkingTime ) { 
    return new ReceiptImpl(parkingTime); 
  }
  
  public RateStrategy createRateStrategy(WeekdayDeterminationStrategy wds) { 
    RateStrategy rs = 
      new CompositeRateStrategy( new LinearRateStrategy(),
                                 new ProgressiveRateStrategy(),
                                 wds );
    return rs; 
  }
  public WeekdayDeterminationStrategy createWeekdayDeterminationStrategy() {
    return new AskUserWeekdayDeterminationStrategy();
  }
  public DisplayStrategy createDisplayStrategy() {
    return new ValueDisplayStrategy();
  }
}

