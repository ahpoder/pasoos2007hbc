package paystation.domain;

import java.util.*;

/** A strategy that determines if it is weekend based on the calendar.

    author: (c) Henrik B�rbak Christensen 2006
*/

public class RealWeekdayDeterminationStrategy 
  implements WeekdayDeterminationStrategy {

  public boolean isWeekend() {
    Date d = new Date();
    Calendar c = new GregorianCalendar();
    c.setTime(d);
    int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
    return ( dayOfWeek == Calendar.SATURDAY 
             || 
             dayOfWeek == Calendar.SUNDAY);
  }

}


