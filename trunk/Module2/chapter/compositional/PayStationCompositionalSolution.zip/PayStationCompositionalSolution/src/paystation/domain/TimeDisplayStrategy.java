package paystation.domain;

import java.util.*;

/** A display strategy that returns time (in local hour format)
    for when parket time expires.

    author: (c) Henrik B�rbak Christensen 2006
*/

public class TimeDisplayStrategy implements DisplayStrategy {
  public int reading(int minutes) { 
    Calendar now = GregorianCalendar.getInstance();
    now.add(Calendar.MINUTE, minutes);
    return 
      now.get(Calendar.HOUR_OF_DAY) * 100 
      + 
      now.get(Calendar.MINUTE);
  }
}

