package paystation.domain;

/** A display strategy that returns number of minutes when
    display is read.

    author: (c) Henrik B�rbak Christensen 2006
*/

public class ValueDisplayStrategy implements DisplayStrategy {
  public int reading( int minutes ) { 
    return minutes;
  }
}

