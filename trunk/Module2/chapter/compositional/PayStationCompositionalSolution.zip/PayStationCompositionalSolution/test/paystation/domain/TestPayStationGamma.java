package paystation.domain;

import junit.framework.*;

public class TestPayStationGamma extends TestCase {

  private PayStation ps;
  private TestWeekdayDeterminationStrategy wds;
  public void setUp() {
    wds = new TestWeekdayDeterminationStrategy();
    ps = new PayStationImpl( new TestGammaTownFactory(wds) );
  }

  /* Gammatown during weekdays: Alphatown's linear rate.*/
  public void testWeekday() throws IllegalCoinException {
    wds.setIsWeekend(false);

    ps.addPayment(25); ps.addPayment(25);
    ps.addPayment(25); ps.addPayment(25);

    ps.addPayment(25); ps.addPayment(25);
    ps.addPayment(25); ps.addPayment(25);

    assertEquals( (8*25) / 5 * 2 , ps.timeBought() );
  }

  /* Gammatown during weekend: Betatown's progressive rate.*/
  public void testWeekend() throws IllegalCoinException {
    wds.setIsWeekend(true);

    ps.addPayment(25); ps.addPayment(25);
    ps.addPayment(25); ps.addPayment(25);

    ps.addPayment(25); ps.addPayment(25);
    ps.addPayment(25); ps.addPayment(25);
    // 200 cent: 150 is 1st hour; 50 cent is 1/4 of next hour
    assertEquals( 75 /* minutes */ , ps.timeBought() );
  }

  
  public static Test suite() {
    return new TestSuite(TestPayStationGamma.class);
  }
}

/** I need to override the WeekdayDeterminationStrategy
    in Gammatown to bring it under testing control.
    Therefore I subclass the GammaTownFactory to override
    it. This proves a bit cumbersome when I do not use
    the object server pattern. */
class TestGammaTownFactory extends GammaTownFactory {
  private WeekdayDeterminationStrategy wds;
  TestGammaTownFactory( WeekdayDeterminationStrategy wds ) {
    this.wds = wds;
  }
  public WeekdayDeterminationStrategy createWeekdayDeterminationStrategy() {
    return wds;
  }
}
