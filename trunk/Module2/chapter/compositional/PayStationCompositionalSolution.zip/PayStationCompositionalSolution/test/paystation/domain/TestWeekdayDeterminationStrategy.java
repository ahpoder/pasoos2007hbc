package paystation.domain;

import java.util.*;

/** A WeekdayDeterminationStrategy that is under testing control.

    author: (c) Henrik B�rbak Christensen 2006
*/

public class TestWeekdayDeterminationStrategy 
  implements WeekdayDeterminationStrategy {

  private boolean isWeekend;
  public TestWeekdayDeterminationStrategy() {
    isWeekend = false;
  }
  public void setIsWeekend( boolean isWeekend ) {
    this.isWeekend = isWeekend;
  }
  public boolean isWeekend() {
    return isWeekend;
  }

}


