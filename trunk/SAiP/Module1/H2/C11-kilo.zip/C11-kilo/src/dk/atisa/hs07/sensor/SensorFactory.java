package dk.atisa.hs07.sensor;

public interface SensorFactory {
	Object createSensor();
}
